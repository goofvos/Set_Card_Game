Beste SET-speler,

SET is een kaartspel met in totaal 81 kaarten, elk met een aantal symbolen met een bepaalde kleur en vulling, waarbij de speler uit een
groep van 12 kaarten een SET moet vinden. De kaarten hebben dus elk 4 eigenschappen: Het aantal symbolen (1,2 of 3), de vorm van het
symbool (cirkel, tilde of diamant), de kleur van het symbool (rood, paars of groen) en de vulling van het symbool (gevuld, leeg of
gestreept). Een SET is een combinatie van 3 kaarten, waarbij de eigenschappen van de kaarten per eigenschap óf alledrie hetzelfde, óf
alledrie verschillend zijn. Een SET zou bijvoorbeeld zijn: Één rode lege diamant, twee rode lege tildes en drie rode lege cirkels.
De kleur en vulling blijven hetzelfde, terwijl de vorm en het aantal verschillen.

Het spel begint met een stapel van 81 kaarten (alle mogelijke combinaties) en hiervan worden er 12 op tafel (het scherm) gelegd, en 
genummerd. De speler en de computer krijgen 30 seconden de tijd om in deze 12 kaarten een SET te vinden. Als de speler een SET vindt, voert
hij/zij deze in door middel van de invoerbalk onderaan het scherm, door de nummers van de kaarten in te voeren, gescheiden door een komma.
Vergeet niet om de balk eerst aan te klikken met de linkermuisknop, om hem "aan te zetten".

Als de speler binnen 30 seconden een SET vindt, dan krijgt de speler een punt, worden de 3 SET-kaarten vervangen door 3 nieuwe kaarten van
de stapel. Als de speler na 30 seconden geen SET heeft gevonden, en er is wel een SET aanwezig op tafel, dan krijgt de computer een punt en
worden de SET-kaarten vervangen door 3 nieuwe kaarten van de stapel. Als er geen SET aanwezig is op tafel, dan krijgt niemand een punt en
worden na 30 seconden de eerste 3 kaarten vervangen door 3 nieuwe kaarten van de stapel.
Op het moment dat de stapel op is, is het spel afgelopen en wie dan de meeste punten heeft, heeft gewonnen!

Hoe het spel op te starten:
1. Om het spel te kunnen spelen dient de speler eerst pygame te installeren. Mocht u pygame al geïnstalleerd hebben, ga door naar stap 2.
Het installeren gaat als volgt: Launch in Anaconda Navigator de applicatie CMD.exe Prompt.
Typ daarin de zin: py -m pip install -U pygame==1.9.6 --user , en druk op enter. Nu zal pygame geïnstalleerd worden.
Een andere methode om pygame te installeren is om Python te installeren via Microsoft Store of Apple Store en vervolgens het programma 
"Opdrachtprompt" of "CMD" op te starten op uw computer. Typ nu dezelfde zin: py -m pip install -U pygame==1.9.6 --user in de terminal en
druk op enter.
2. Als pygame succesvol geïnstalleerd is, opent u het bestand setgame.py, dat zich in dezelfde map bevindt als dit .txt bestand, in Spyder.
3. Vervolgens drukt u op "F5" of het groene pijltje bovenaan het scherm en zo wordt het spel opgestart. Als u een error krijgt genaamd
"No module named 'pygame'", is pygame niet succesvol geïnstalleerd. Ga dus terug naar stap 1.
4. Om te beginnen met het spel, klikt u ergens op het scherm. Het spel is nu begonnen.
5. Om een SET in te voeren, zet u de invoerbalk aan door er op te klikken en voert u de nummers van de SET-kaarten in gescheiden door
komma's (bijvoorbeeld 8,10,12).

